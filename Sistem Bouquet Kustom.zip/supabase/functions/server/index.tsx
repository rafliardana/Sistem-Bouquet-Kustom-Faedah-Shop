import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js";
import * as kv from "./kv_store.tsx";

const app = new Hono();

app.use("*", logger(console.log));
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

const PREFIX = "/make-server-205999f8";
const BUCKET = "make-205999f8-uploads";

// Service-role client (full access). Never expose the service role key to the frontend.
const admin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

// ─────────────────────────────────────────────────────────────
// Startup: ensure storage bucket exists (idempotent)
// ─────────────────────────────────────────────────────────────
async function ensureBucket() {
  try {
    const { data: buckets } = await admin.storage.listBuckets();
    const exists = buckets?.some((b) => b.name === BUCKET);
    if (!exists) {
      await admin.storage.createBucket(BUCKET, { public: false });
      console.log(`Created storage bucket ${BUCKET}`);
    }
  } catch (e) {
    console.log(`Error ensuring storage bucket ${BUCKET}: ${e}`);
  }
}
ensureBucket();

// ─────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────
type Role = "owner" | "admin" | "customer";

interface Profile {
  id: string;
  email: string;
  name: string;
  role: Role;
  createdAt: string;
}

// Verify the access token from the Authorization header and return the user + stored profile.
async function getAuth(c: any): Promise<{ userId: string; profile: Profile } | null> {
  const accessToken = c.req.header("Authorization")?.split(" ")[1];
  if (!accessToken) return null;
  const { data, error } = await admin.auth.getUser(accessToken);
  if (error || !data?.user?.id) {
    console.log(`Auth token verification failed: ${error?.message ?? "no user"}`);
    return null;
  }
  const profile = (await kv.get(`user:${data.user.id}`)) as Profile | undefined;
  if (!profile) {
    console.log(`No stored profile for authenticated user ${data.user.id}`);
    return null;
  }
  return { userId: data.user.id, profile };
}

// Upload a base64 data URL to storage and return its stored path. Returns null if no data provided.
async function uploadDataUrl(dataUrl: string | null | undefined, keyHint: string): Promise<string | null> {
  if (!dataUrl || !dataUrl.startsWith("data:")) return null;
  try {
    const match = dataUrl.match(/^data:(.+?);base64,(.*)$/);
    if (!match) return null;
    const contentType = match[1];
    const bytes = Uint8Array.from(atob(match[2]), (ch) => ch.charCodeAt(0));
    const ext = contentType.split("/")[1]?.split("+")[0] ?? "bin";
    const path = `${keyHint}-${crypto.randomUUID()}.${ext}`;
    const { error } = await admin.storage.from(BUCKET).upload(path, bytes, { contentType, upsert: false });
    if (error) {
      console.log(`Storage upload error for ${path}: ${error.message}`);
      return null;
    }
    return path;
  } catch (e) {
    console.log(`Unexpected error uploading data url (${keyHint}): ${e}`);
    return null;
  }
}

// Create a temporary signed URL for a stored path.
async function signedUrl(path: string | null | undefined): Promise<string | null> {
  if (!path) return null;
  try {
    const { data, error } = await admin.storage.from(BUCKET).createSignedUrl(path, 60 * 60);
    if (error) {
      console.log(`Signed URL error for ${path}: ${error.message}`);
      return null;
    }
    return data?.signedUrl ?? null;
  } catch (e) {
    console.log(`Unexpected error signing url ${path}: ${e}`);
    return null;
  }
}

// Convert a stored order (with storage paths) into a client-facing order (with signed URLs).
async function hydrateOrder(order: any) {
  const referenceImagePreview = await signedUrl(order.customization?.referenceImagePath);
  const paymentProofPreview = await signedUrl(order.paymentProofPath);
  return {
    id: order.id,
    orderNumber: order.orderNumber,
    userId: order.userId,
    customerEmail: order.customerEmail,
    product: order.product,
    customization: {
      sizeId: order.customization.sizeId,
      description: order.customization.description ?? "",
      selectedAddonIds: order.customization.selectedAddonIds ?? [],
      referenceImagePreview,
    },
    totalPrice: order.totalPrice,
    status: order.status,
    createdAt: order.createdAt,
    customerName: order.customerName,
    customerPhone: order.customerPhone,
    customerAddress: order.customerAddress,
    paymentMethod: order.paymentMethod,
    paymentMethodLabel: order.paymentMethodLabel ?? order.paymentMethod,
    paymentProofPreview,
  };
}

const STATUS_ORDER = ["menunggu_konfirmasi", "dalam_proses", "pesanan_siap", "selesai"];

// ─────────────────────────────────────────────────────────────
// Default product seed (matches the original hardcoded catalog)
// ─────────────────────────────────────────────────────────────
const COMMON_SIZES = [
  { id: "S", label: "Kecil", stems: "5–7 tangkai", priceMultiplier: 1 },
  { id: "M", label: "Sedang", stems: "10–15 tangkai", priceMultiplier: 1.7 },
  { id: "L", label: "Besar", stems: "20–25 tangkai", priceMultiplier: 2.4 },
  { id: "XL", label: "Extra Besar", stems: "30+ tangkai", priceMultiplier: 3.2 },
];
const COMMON_ADDONS = [
  { id: "vase", label: "Vas Bunga", price: 75000 },
  { id: "ribbon", label: "Pita Premium", price: 25000 },
  { id: "card", label: "Kartu Ucapan", price: 15000 },
  { id: "wrap", label: "Wrapping Mewah", price: 40000 },
];
const SEED_PRODUCTS = [
  { id: "p1", name: "Classic Rose Bouquet", description: "Rangkaian mawar klasik yang elegan dan mewah. Cocok untuk berbagai momen spesial seperti ulang tahun, anniversari, atau ungkapan rasa cinta.", basePrice: 150000, image: "https://images.unsplash.com/photo-1487530811176-3780de880c2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600", category: "Mawar", sizes: COMMON_SIZES, addons: COMMON_ADDONS },
  { id: "p2", name: "Pink Romance", description: "Perpaduan mawar pink dan putih yang romantis, didekorasi dengan dedaunan hijau segar. Pilihan sempurna untuk mengungkapkan kasih sayang.", basePrice: 175000, image: "https://images.unsplash.com/photo-1523693916903-027d144a2b7d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600", category: "Mawar", sizes: COMMON_SIZES, addons: COMMON_ADDONS },
  { id: "p3", name: "Tropical Garden Mix", description: "Perpaduan bunga-bunga tropis berwarna-warni yang segar dan menawan. Tampilan unik yang membuatnya berbeda dari buket biasa.", basePrice: 130000, image: "https://images.unsplash.com/photo-1572454591674-2739f30d8c40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600", category: "Campur", sizes: COMMON_SIZES, addons: COMMON_ADDONS },
  { id: "p4", name: "Dried Floral Collection", description: "Rangkaian bunga kering premium dengan tekstur unik dan nuansa bohemian. Tahan lama dan cocok sebagai dekorasi rumah.", basePrice: 140000, image: "https://images.unsplash.com/photo-1622658641561-fe2ca339b039?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600", category: "Bunga Kering", sizes: [{ id: "S", label: "Kecil", stems: "5–8 tangkai", priceMultiplier: 1 }, { id: "M", label: "Sedang", stems: "12–15 tangkai", priceMultiplier: 1.6 }, { id: "L", label: "Besar", stems: "20–25 tangkai", priceMultiplier: 2.3 }, { id: "XL", label: "Extra Besar", stems: "30+ tangkai", priceMultiplier: 3 }], addons: [{ id: "frame", label: "Frame Gantung", price: 95000 }, { id: "ribbon", label: "Pita Satin", price: 25000 }, { id: "card", label: "Kartu Ucapan", price: 15000 }, { id: "wrap", label: "Kraft Paper Wrap", price: 30000 }] },
  { id: "p5", name: "Sunflower Joy", description: "Buket bunga matahari ceria yang memancarkan kehangatan dan kebahagiaan. Pilihan tepat untuk menyemangati orang-orang tersayang.", basePrice: 115000, image: "https://images.unsplash.com/photo-1601884928885-92a922f7962f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600", category: "Bunga Matahari", sizes: COMMON_SIZES, addons: COMMON_ADDONS },
  { id: "p6", name: "Tulip Garden", description: "Rangkaian tulip segar yang anggun dan minimalis. Tersedia dalam berbagai warna pilihan sesuai permintaanmu.", basePrice: 165000, image: "https://images.unsplash.com/photo-1586968295564-92fd7572718b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600", category: "Tulip", sizes: [{ id: "S", label: "Kecil", stems: "5–7 tangkai", priceMultiplier: 1 }, { id: "M", label: "Sedang", stems: "10–12 tangkai", priceMultiplier: 1.6 }, { id: "L", label: "Besar", stems: "18–20 tangkai", priceMultiplier: 2.2 }, { id: "XL", label: "Extra Besar", stems: "25+ tangkai", priceMultiplier: 2.9 }], addons: COMMON_ADDONS },
];

async function ensureSeed() {
  const existing = await kv.getByPrefix("product:");
  if (!existing || existing.length === 0) {
    await kv.mset(
      SEED_PRODUCTS.map((p) => `product:${p.id}`),
      SEED_PRODUCTS,
    );
    console.log("Seeded default products");
  }
}

const PAYMENT_SETTINGS_KEY = "settings:payment_methods";
const DEFAULT_PAYMENT_METHODS = [
  { id: "transfer_bca", label: "Transfer BCA", detail: "BCA 1234567890  •  a/n Faedah Shop", needsProof: true },
  { id: "transfer_mandiri", label: "Transfer Mandiri", detail: "Mandiri 0987654321  •  a/n Faedah Shop", needsProof: true },
  { id: "gopay", label: "GoPay", detail: "0812-3456-7890  •  (Faedah Shop)", needsProof: true },
  { id: "ovo", label: "OVO", detail: "0812-3456-7890  •  (Faedah Shop)", needsProof: true },
  { id: "cod", label: "COD (Bayar di Tempat)", detail: "Bayar tunai saat pesanan tiba", needsProof: false },
];

async function getPaymentMethods(): Promise<any[]> {
  let methods = (await kv.get(PAYMENT_SETTINGS_KEY)) as any[] | undefined;
  if (!methods || methods.length === 0) {
    methods = DEFAULT_PAYMENT_METHODS;
    await kv.set(PAYMENT_SETTINGS_KEY, methods);
    console.log("Seeded default payment methods");
  }
  return methods;
}

function computeTotal(product: any, sizeId: string, selectedAddonIds: string[]): number {
  const size = product.sizes.find((s: any) => s.id === sizeId);
  const multiplier = size?.priceMultiplier ?? 1;
  const flowerPrice = Math.round(product.basePrice * multiplier);
  const addonTotal = (selectedAddonIds ?? []).reduce((sum: number, id: string) => {
    const addon = product.addons.find((a: any) => a.id === id);
    return sum + (addon?.price ?? 0);
  }, 0);
  return flowerPrice + addonTotal;
}

// ─────────────────────────────────────────────────────────────
// Health
// ─────────────────────────────────────────────────────────────
app.get(`${PREFIX}/health`, (c) => c.json({ status: "ok" }));

// ─────────────────────────────────────────────────────────────
// Products (public read + lazy seed)
// ─────────────────────────────────────────────────────────────
app.get(`${PREFIX}/products`, async (c) => {
  try {
    await ensureSeed();
    const products = await kv.getByPrefix("product:");
    return c.json({ products });
  } catch (e) {
    console.log(`Error listing products: ${e}`);
    return c.json({ error: `Failed to list products: ${e}` }, 500);
  }
});

// ─────────────────────────────────────────────────────────────
// Payment methods (public read + staff edit)
// ─────────────────────────────────────────────────────────────
app.get(`${PREFIX}/payment-methods`, async (c) => {
  try {
    const methods = await getPaymentMethods();
    return c.json({ methods });
  } catch (e) {
    console.log(`Error listing payment methods: ${e}`);
    return c.json({ error: `Gagal memuat metode pembayaran: ${e}` }, 500);
  }
});

app.put(`${PREFIX}/admin/payment-methods`, async (c) => {
  try {
    const auth = await getAuth(c);
    if (!auth || (auth.profile.role !== "admin" && auth.profile.role !== "owner")) {
      return c.json({ error: "Forbidden: hanya admin/owner" }, 403);
    }
    const body = await c.req.json();
    const incoming = Array.isArray(body.methods) ? body.methods : [];
    const methods = incoming
      .filter((m: any) => m && m.id && m.label)
      .map((m: any) => ({
        id: String(m.id),
        label: String(m.label),
        detail: String(m.detail ?? ""),
        needsProof: !!m.needsProof,
      }));
    if (methods.length === 0) {
      return c.json({ error: "Minimal satu metode pembayaran wajib ada" }, 400);
    }
    await kv.set(PAYMENT_SETTINGS_KEY, methods);
    return c.json({ methods });
  } catch (e) {
    console.log(`Error saving payment methods: ${e}`);
    return c.json({ error: `Gagal menyimpan metode pembayaran: ${e}` }, 500);
  }
});

// ─────────────────────────────────────────────────────────────
// Auth: owner bootstrap + customer signup + profile
// ─────────────────────────────────────────────────────────────
app.get(`${PREFIX}/has-owner`, async (c) => {
  try {
    const users = (await kv.getByPrefix("user:")) as Profile[];
    const exists = users.some((u) => u.role === "owner");
    return c.json({ exists });
  } catch (e) {
    console.log(`Error checking owner existence: ${e}`);
    return c.json({ error: `Failed to check owner: ${e}` }, 500);
  }
});

// Create the first owner. Only works if no owner exists yet (idempotent guard).
app.post(`${PREFIX}/bootstrap/owner`, async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    if (!email || !password || !name) {
      return c.json({ error: "Email, password, dan nama wajib diisi untuk bootstrap owner" }, 400);
    }
    const users = (await kv.getByPrefix("user:")) as Profile[];
    if (users.some((u) => u.role === "owner")) {
      return c.json({ error: "Owner sudah ada. Bootstrap hanya bisa dilakukan sekali." }, 409);
    }
    const { data, error } = await admin.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true,
    });
    if (error || !data?.user) {
      console.log(`Error creating owner during bootstrap: ${error?.message}`);
      return c.json({ error: `Gagal membuat owner: ${error?.message}` }, 400);
    }
    const profile: Profile = { id: data.user.id, email, name, role: "owner", createdAt: new Date().toISOString() };
    await kv.set(`user:${data.user.id}`, profile);
    return c.json({ profile });
  } catch (e) {
    console.log(`Unexpected error during owner bootstrap: ${e}`);
    return c.json({ error: `Bootstrap owner gagal: ${e}` }, 500);
  }
});

// Customer self-registration.
app.post(`${PREFIX}/signup`, async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    if (!email || !password || !name) {
      return c.json({ error: "Email, password, dan nama wajib diisi" }, 400);
    }
    const { data, error } = await admin.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true,
    });
    if (error || !data?.user) {
      console.log(`Error during customer signup: ${error?.message}`);
      return c.json({ error: `Gagal mendaftar: ${error?.message}` }, 400);
    }
    const profile: Profile = { id: data.user.id, email, name, role: "customer", createdAt: new Date().toISOString() };
    await kv.set(`user:${data.user.id}`, profile);
    return c.json({ profile });
  } catch (e) {
    console.log(`Unexpected error during signup: ${e}`);
    return c.json({ error: `Pendaftaran gagal: ${e}` }, 500);
  }
});

app.get(`${PREFIX}/me`, async (c) => {
  const auth = await getAuth(c);
  if (!auth) return c.json({ error: "Unauthorized" }, 401);
  return c.json({ profile: auth.profile });
});

// ─────────────────────────────────────────────────────────────
// Orders
// ─────────────────────────────────────────────────────────────
// Create order (customer must be logged in).
app.post(`${PREFIX}/orders`, async (c) => {
  try {
    const auth = await getAuth(c);
    if (!auth) return c.json({ error: "Unauthorized: silakan login untuk membuat pesanan" }, 401);

    const body = await c.req.json();
    const { productId, sizeId, description, selectedAddonIds, customerName, customerPhone, customerAddress, paymentMethod, referenceImageBase64, paymentProofBase64 } = body;

    const product = await kv.get(`product:${productId}`);
    if (!product) return c.json({ error: `Produk tidak ditemukan: ${productId}` }, 400);
    if (!sizeId || !customerName || !customerPhone || !customerAddress || !paymentMethod) {
      return c.json({ error: "Data pesanan tidak lengkap" }, 400);
    }

    const totalPrice = computeTotal(product, sizeId, selectedAddonIds ?? []);
    const referenceImagePath = await uploadDataUrl(referenceImageBase64, `reference/${auth.userId}`);
    const paymentProofPath = await uploadDataUrl(paymentProofBase64, `proof/${auth.userId}`);

    // Snapshot the payment method label so it stays correct even if settings change later.
    const methods = await getPaymentMethods();
    const paymentMethodLabel = methods.find((m) => m.id === paymentMethod)?.label ?? paymentMethod;

    const id = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
    const order = {
      id,
      orderNumber: `FLR-${Date.now().toString().slice(-6)}`,
      userId: auth.userId,
      customerEmail: auth.profile.email,
      product,
      customization: { sizeId, description: description ?? "", selectedAddonIds: selectedAddonIds ?? [], referenceImagePath },
      totalPrice,
      status: "menunggu_konfirmasi",
      createdAt: new Date().toISOString(),
      customerName,
      customerPhone,
      customerAddress,
      paymentMethod,
      paymentMethodLabel,
      paymentProofPath,
    };
    await kv.set(`order:${id}`, order);
    return c.json({ order: await hydrateOrder(order) });
  } catch (e) {
    console.log(`Error creating order: ${e}`);
    return c.json({ error: `Gagal membuat pesanan: ${e}` }, 500);
  }
});

// List orders. Customers see only their own; admin/owner see all.
app.get(`${PREFIX}/orders`, async (c) => {
  try {
    const auth = await getAuth(c);
    if (!auth) return c.json({ error: "Unauthorized" }, 401);
    let orders = (await kv.getByPrefix("order:")) as any[];
    if (auth.profile.role === "customer") {
      orders = orders.filter((o) => o.userId === auth.userId);
    }
    orders.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
    const hydrated = await Promise.all(orders.map(hydrateOrder));
    return c.json({ orders: hydrated });
  } catch (e) {
    console.log(`Error listing orders: ${e}`);
    return c.json({ error: `Gagal memuat pesanan: ${e}` }, 500);
  }
});

// Advance / set order status (admin + owner).
app.patch(`${PREFIX}/admin/orders/:id/status`, async (c) => {
  try {
    const auth = await getAuth(c);
    if (!auth || (auth.profile.role !== "admin" && auth.profile.role !== "owner")) {
      return c.json({ error: "Forbidden: hanya admin/owner" }, 403);
    }
    const id = c.req.param("id");
    const order = await kv.get(`order:${id}`);
    if (!order) return c.json({ error: "Pesanan tidak ditemukan" }, 404);

    const body = await c.req.json().catch(() => ({}));
    let nextStatus: string;
    if (body.status && STATUS_ORDER.includes(body.status)) {
      nextStatus = body.status;
    } else {
      // default: advance to the next stage
      const idx = STATUS_ORDER.indexOf(order.status);
      nextStatus = STATUS_ORDER[Math.min(idx + 1, STATUS_ORDER.length - 1)];
    }
    order.status = nextStatus;
    await kv.set(`order:${id}`, order);
    return c.json({ order: await hydrateOrder(order) });
  } catch (e) {
    console.log(`Error updating order status: ${e}`);
    return c.json({ error: `Gagal memperbarui status: ${e}` }, 500);
  }
});

// ─────────────────────────────────────────────────────────────
// Admin products (admin + owner)
// ─────────────────────────────────────────────────────────────
async function requireStaff(c: any) {
  const auth = await getAuth(c);
  if (!auth || (auth.profile.role !== "admin" && auth.profile.role !== "owner")) return null;
  return auth;
}

app.post(`${PREFIX}/admin/products`, async (c) => {
  try {
    const auth = await requireStaff(c);
    if (!auth) return c.json({ error: "Forbidden: hanya admin/owner" }, 403);
    const body = await c.req.json();
    const id = body.id || `p-${crypto.randomUUID().slice(0, 8)}`;
    const product = {
      id,
      name: body.name,
      description: body.description ?? "",
      basePrice: Number(body.basePrice) || 0,
      image: body.image ?? "",
      category: body.category ?? "Campur",
      sizes: body.sizes?.length ? body.sizes : COMMON_SIZES,
      addons: body.addons?.length ? body.addons : COMMON_ADDONS,
    };
    if (!product.name) return c.json({ error: "Nama produk wajib diisi" }, 400);
    await kv.set(`product:${id}`, product);
    return c.json({ product });
  } catch (e) {
    console.log(`Error creating product: ${e}`);
    return c.json({ error: `Gagal membuat produk: ${e}` }, 500);
  }
});

app.patch(`${PREFIX}/admin/products/:id`, async (c) => {
  try {
    const auth = await requireStaff(c);
    if (!auth) return c.json({ error: "Forbidden: hanya admin/owner" }, 403);
    const id = c.req.param("id");
    const existing = await kv.get(`product:${id}`);
    if (!existing) return c.json({ error: "Produk tidak ditemukan" }, 404);
    const body = await c.req.json();
    const updated = {
      ...existing,
      ...body,
      id,
      basePrice: body.basePrice !== undefined ? Number(body.basePrice) : existing.basePrice,
    };
    await kv.set(`product:${id}`, updated);
    return c.json({ product: updated });
  } catch (e) {
    console.log(`Error updating product: ${e}`);
    return c.json({ error: `Gagal memperbarui produk: ${e}` }, 500);
  }
});

app.delete(`${PREFIX}/admin/products/:id`, async (c) => {
  try {
    const auth = await requireStaff(c);
    if (!auth) return c.json({ error: "Forbidden: hanya admin/owner" }, 403);
    const id = c.req.param("id");
    await kv.del(`product:${id}`);
    return c.json({ ok: true });
  } catch (e) {
    console.log(`Error deleting product: ${e}`);
    return c.json({ error: `Gagal menghapus produk: ${e}` }, 500);
  }
});

// ─────────────────────────────────────────────────────────────
// Owner-only: stats
// ─────────────────────────────────────────────────────────────
app.get(`${PREFIX}/admin/stats`, async (c) => {
  try {
    const auth = await getAuth(c);
    if (!auth || auth.profile.role !== "owner") return c.json({ error: "Forbidden: hanya owner" }, 403);
    const orders = (await kv.getByPrefix("order:")) as any[];

    const statusCounts: Record<string, number> = { menunggu_konfirmasi: 0, dalam_proses: 0, pesanan_siap: 0, selesai: 0 };
    let totalRevenue = 0;
    const dayMap: Record<string, { revenue: number; orders: number }> = {};
    const productMap: Record<string, number> = {};

    for (const o of orders) {
      statusCounts[o.status] = (statusCounts[o.status] ?? 0) + 1;
      totalRevenue += o.totalPrice ?? 0;
      const day = (o.createdAt ?? "").slice(0, 10);
      if (day) {
        dayMap[day] = dayMap[day] ?? { revenue: 0, orders: 0 };
        dayMap[day].revenue += o.totalPrice ?? 0;
        dayMap[day].orders += 1;
      }
      const pname = o.product?.name ?? "Lainnya";
      productMap[pname] = (productMap[pname] ?? 0) + 1;
    }

    const revenueByDay = Object.entries(dayMap)
      .map(([date, v]) => ({ date, revenue: v.revenue, orders: v.orders }))
      .sort((a, b) => (a.date < b.date ? -1 : 1));
    const topProducts = Object.entries(productMap)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    return c.json({
      stats: { totalOrders: orders.length, totalRevenue, statusCounts, revenueByDay, topProducts },
    });
  } catch (e) {
    console.log(`Error computing stats: ${e}`);
    return c.json({ error: `Gagal memuat statistik: ${e}` }, 500);
  }
});

// ─────────────────────────────────────────────────────────────
// Owner-only: manage admin accounts
// ─────────────────────────────────────────────────────────────
app.get(`${PREFIX}/admin/accounts`, async (c) => {
  try {
    const auth = await getAuth(c);
    if (!auth || auth.profile.role !== "owner") return c.json({ error: "Forbidden: hanya owner" }, 403);
    const users = (await kv.getByPrefix("user:")) as Profile[];
    const admins = users.filter((u) => u.role === "admin");
    return c.json({ accounts: admins });
  } catch (e) {
    console.log(`Error listing admin accounts: ${e}`);
    return c.json({ error: `Gagal memuat akun admin: ${e}` }, 500);
  }
});

app.post(`${PREFIX}/admin/accounts`, async (c) => {
  try {
    const auth = await getAuth(c);
    if (!auth || auth.profile.role !== "owner") return c.json({ error: "Forbidden: hanya owner" }, 403);
    const { email, password, name } = await c.req.json();
    if (!email || !password || !name) return c.json({ error: "Email, password, dan nama wajib diisi" }, 400);
    const { data, error } = await admin.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true,
    });
    if (error || !data?.user) {
      console.log(`Error creating admin account: ${error?.message}`);
      return c.json({ error: `Gagal membuat akun admin: ${error?.message}` }, 400);
    }
    const profile: Profile = { id: data.user.id, email, name, role: "admin", createdAt: new Date().toISOString() };
    await kv.set(`user:${data.user.id}`, profile);
    return c.json({ account: profile });
  } catch (e) {
    console.log(`Error creating admin account: ${e}`);
    return c.json({ error: `Gagal membuat akun admin: ${e}` }, 500);
  }
});

app.delete(`${PREFIX}/admin/accounts/:id`, async (c) => {
  try {
    const auth = await getAuth(c);
    if (!auth || auth.profile.role !== "owner") return c.json({ error: "Forbidden: hanya owner" }, 403);
    const id = c.req.param("id");
    const target = (await kv.get(`user:${id}`)) as Profile | undefined;
    if (!target || target.role !== "admin") return c.json({ error: "Akun admin tidak ditemukan" }, 404);
    await admin.auth.admin.deleteUser(id);
    await kv.del(`user:${id}`);
    return c.json({ ok: true });
  } catch (e) {
    console.log(`Error deleting admin account: ${e}`);
    return c.json({ error: `Gagal menghapus akun admin: ${e}` }, 500);
  }
});

Deno.serve(app.fetch);
