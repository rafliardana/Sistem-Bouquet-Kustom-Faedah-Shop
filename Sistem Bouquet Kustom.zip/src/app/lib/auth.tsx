import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { supabase } from "./supabase";
import { getProfile, signupCustomer } from "./api";
import type { UserProfile } from "../components/types";

interface AuthContextValue {
  profile: UserProfile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<UserProfile>;
  signUp: (email: string, password: string, name: string) => Promise<UserProfile>;
  signOut: () => Promise<void>;
  refresh: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) {
      setProfile(null);
      return;
    }
    try {
      const p = await getProfile();
      setProfile(p);
    } catch (e) {
      console.error("Failed to load profile for active session:", e);
      setProfile(null);
    }
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      await loadProfile();
      if (active) setLoading(false);
    })();
    const { data: sub } = supabase.auth.onAuthStateChange(() => {
      loadProfile();
    });
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, [loadProfile]);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      console.error("Sign in error:", error.message);
      throw new Error(error.message);
    }
    const p = await getProfile();
    setProfile(p);
    return p;
  }, []);

  const signUp = useCallback(async (email: string, password: string, name: string) => {
    // Create the user server-side (auto-confirmed), then sign in.
    await signupCustomer(email, password, name);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      console.error("Sign in after signup error:", error.message);
      throw new Error(error.message);
    }
    const p = await getProfile();
    setProfile(p);
    return p;
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setProfile(null);
  }, []);

  return (
    <AuthContext.Provider value={{ profile, loading, signIn, signUp, signOut, refresh: loadProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
