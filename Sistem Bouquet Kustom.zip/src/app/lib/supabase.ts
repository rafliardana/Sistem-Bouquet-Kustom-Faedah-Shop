import { createClient } from "@supabase/supabase-js";
import { projectId, publicAnonKey } from "/utils/supabase/info";

// Singleton Supabase client for the frontend (auth only — data goes through the edge server).
export const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey,
);

export const SERVER_URL = `https://${projectId}.supabase.co/functions/v1/make-server-205999f8`;
export { projectId, publicAnonKey };
